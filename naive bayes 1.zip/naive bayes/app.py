from flask import Flask, render_template, request

app = Flask(__name__)

# ========== HOME PAGE ==========
@app.route('/')
def home():
    return render_template('index.html')


# ========== ANIMAL INFO ==========
@app.route('/animal')
def animal_page():
    return render_template('animal.html')

@app.route('/predict_animal', methods=['POST'])
def predict_animal():
    try:
        size = request.form.get('size', '').strip().lower()
        color = request.form.get('color', '').strip().lower()

        # Debug: print values to terminal
        print("Size:", size, "Color:", color)

        if size == "big" and color == "white":
            prediction = "Cow"
        elif size == "big" and color == "black":
            prediction = "Dog"
        elif size == "small" and color == "white":
            prediction = "Rat"
        elif size == "small" and color == "brown":
            prediction = "Rabbit"
        elif size == "medium" and color == "black":
            prediction = "Dog"
        else:
            prediction = "Unknown Animal"

        return render_template('animal.html', result=f"Predicted Animal: {prediction}")
    except Exception as e:
        return render_template('animal.html', result=f"Error: {e}")


# ========== EMAIL SPAM ==========
@app.route('/email')
def email_page():
    return render_template('email.html')

@app.route('/predict_email', methods=['POST'])
def predict_email():
    try:
        text = request.form['text']
        # String-based spam check
        spam_words = ["offer", "win", "prize", "free", "money", "click"]
        if any(word in text.lower() for word in spam_words):
            result = "Spam"
        else:
            result = "Not Spam"
        return render_template('email.html', result=f"Prediction: {result}")
    except Exception as e:
        return render_template('email.html', result=f"Error: {e}")


# ========== LOAN APPROVAL ==========
@app.route('/loan')
def loan_page():
    return render_template('loan.html')

@app.route('/predict_loan', methods=['POST'])
def predict_loan():
    income = request.form['income'].lower()
    credit = request.form['credit'].lower()

    if (income in ["high", "good", "above average"]) and (credit in ["excellent", "good", "high"]):
        result = "Loan Approved"
    elif (income in ["medium", "average"]) and (credit in ["fair", "average"]):
        result = "Loan Pending - Need More Info"
    else:
        result = "Loan Rejected"

    return render_template('loan.html', result=f"Prediction: {result}")


# ========== WEATHER CONDITION ==========
@app.route('/weather')
def weather_page():
    return render_template('weather.html')

@app.route('/predict_weather', methods=['POST'])
def predict_weather():
    try:
        weather = request.form['weather']  # e.g., "Rainy", "Sunny", "Cloudy"
        road = request.form['road']        # e.g., "Wet", "Dry", "Foggy"

        # Simple string-based logic
        if weather.lower() == "rainy" and road.lower() == "wet":
            result = "Drive Carefully"
        elif weather.lower() == "foggy":
            result = "Low Visibility - Slow Down"
        elif weather.lower() == "sunny" and road.lower() == "dry":
            result = "Good to Go"
        else:
            result = "Moderate Condition"

        return render_template('weather.html', result=f"Prediction: {result}")

    except Exception as e:
        return render_template('weather.html', result=f"Error: {e}")


# ========== MAIN ==========
if __name__ == "__main__":
    app.run(debug=True)
